<?php  
ob_start();
require("utility1.php"); ?>

<?php
$name=$_POST['ename'];
$emailid=$_POST['emailid'];
$mobilenumber=$_POST['mobilenumber'];
$username=$_POST['usename'];
$passwprd=$_POST['password'];

$sql=" INSERT INTO userdetails(Name,emailid,mobilenumber,username,password) values ('$name','$emailid','$mobilenumber','$username','$password')";

$result=ExecuteNonQuery ($sql);

if($result)
{
	echo "<h1> YOU ARE REGISTERED </h1> " ;
	echo "Redirecting...";
        header("refresh:2;url=index.html");
}
else
{
	echo "<h1> Register again </h1> " ;	
	echo "Redirecting...";
        header("refresh:2;url=blog.html");
}
?> 	






































































































