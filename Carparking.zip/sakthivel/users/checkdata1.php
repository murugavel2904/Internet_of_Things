<?php
$host = 'localhost';
$user = 'root';
$pass = '';

mysql_connect($host, $user, $pass);

mysql_select_db('car');
 $emailid=$_POST['emailid'];
 $password=$_POST['password'];
//echo "$username"."$password";
 $checkdata=" SELECT * FROM userdetails WHERE emailid='$emailid' AND password='$password'";
 /*$checkdata=" SELECT * FROM student WHERE password='$password'";*/


 $query=mysql_query($checkdata);

 if(mysql_num_rows($query)>'0')
 {
     
     header("Location:checktype.php");
 }
 else
 {
echo "Invaild password";
header("refresh:2;url=services.html");
 }
 exit();
 ?>


