<html>
<head>
<title> slot pages </title>
</head>
<body >

<h1>HANDY CAR PARKING SYSTEM </h1>

<?php
$host = 'localhost';
$user = 'root';
$pass = '';

mysql_connect($host, $user, $pass);

mysql_select_db('car');
//$status='0';
$sql=mysql_query(" SELECT status FROM capacity WHERE slave='Maharaja' "); 
$re=mysql_fetch_array($sql);
//echo $re[0];

//$result=ExecuteNonQuery ($sql);
if($re[0]=="0"){
	$query = mysql_query("UPDATE capacity SET status='1' WHERE (idnumber='0')");

//$status++;

echo "You are booked";
}
else 
{
	echo "<h2>slot is busy </h2>";
}

?>
<a href="index.html" type="submit" value="submit">logut </a>

</body>
</html>