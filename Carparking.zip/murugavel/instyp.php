<?php
include('utility.php');
$master=$_POST['master'];
$slave=$_POST['slave'];$count=$_POST['count'];
//echo "$count"."$slave";
$temp=0;
$result1 = mysql_query("insert into types values ('$master','$slave') ");


for($i=0;$i<$count;$i++)
{
	
$result2 = mysql_query("insert into  capacity values ('$slave','$i','$temp') ");
	
}
 echo "created sucessfully";

?>