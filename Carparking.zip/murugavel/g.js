$(document).ready(function(){
  $.ajax({
    url:"http://www.ksrctiot.com/chart.php",
    //url:"http://localhost/test/chart.php",
    method:"GET",
    success:function(data){
      console.log(data);
      var time=[];
      var field1=[];
      var field2=[];
      var field3=[];
      var field4=[];
      var field5=[];
      var field6=[];
      for (var i in data) {
        time.push(data[i].time);
        field1.push(data[i].field1);
        field2.push(data[i].field2);
        field3.push(data[i].field3);
        field4.push(data[i].field4);
        field5.push(data[i].field5);
        field6.push(data[i].field6);
      }
          },
    error:function(data){
      console.log(data);
    }
  });
});
