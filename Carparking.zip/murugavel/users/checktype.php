<?php

include('utility.php');
?>
<body>
<form action="selectt.php" method="post">
<select name="master" value="">
<option>Theater</option>
<option>Mall</option>
</select>
<input type="submit" value="submit">
</form>
</body>
<?php
?>