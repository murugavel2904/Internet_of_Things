<table border="1"><tr><td>Slot id</td><td>Status</td></tr>
<?php 

include('utility.php');
$slave=$_POST['slave'];

$result = mysql_query("SELECT * FROM capacity where slave='$slave'");
						while($row = mysql_fetch_array($result))
							{
								$id=$row['idnumber'];
								$status=$row['status'];
								?>

<tr><td><?php  echo "$id";?></td><td> <?php echo "$status"; ?></td></tr>
							<?php }
							?>
</table>