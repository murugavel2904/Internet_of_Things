-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2017 at 05:32 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cps`
--

-- --------------------------------------------------------

--
-- Table structure for table `capacity`
--

CREATE TABLE `capacity` (
  `slave` varchar(100) NOT NULL,
  `idnumber` int(10) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `capacity`
--

INSERT INTO `capacity` (`slave`, `idnumber`, `status`) VALUES
('sathyam', 0, 0),
('sathyam', 1, 0),
('sathyam', 2, 0),
('sathyam', 3, 0),
('sathyam', 4, 0),
('sathyam', 5, 0),
('sathyam', 6, 0),
('sathyam', 7, 0),
('sathyam', 8, 0),
('sathyam', 9, 0),
('mayajal', 0, 0),
('mayajal', 1, 0),
('mayajal', 2, 0),
('mayajal', 3, 0),
('mayajal', 4, 0),
('mayajal', 5, 0),
('mayajal', 6, 0),
('mayajal', 7, 0),
('mayajal', 8, 0),
('mayajal', 9, 0),
('mayajal', 10, 0),
('mayajal', 11, 0),
('mayajal', 12, 0),
('mayajal', 13, 0),
('mayajal', 14, 0),
('mayajal', 15, 0),
('mayajal', 16, 0),
('mayajal', 17, 0),
('mayajal', 18, 0),
('mayajal', 19, 0),
('phoenix', 0, 0),
('phoenix', 1, 0),
('phoenix', 2, 0),
('phoenix', 3, 0),
('phoenix', 4, 0),
('phoenix', 5, 0),
('phoenix', 6, 0),
('phoenix', 7, 0),
('phoenix', 8, 0),
('phoenix', 9, 0),
('spencers', 0, 0),
('spencers', 1, 0),
('spencers', 2, 0),
('spencers', 3, 0),
('spencers', 4, 0),
('spencers', 5, 0),
('spencers', 6, 0),
('spencers', 7, 0),
('spencers', 8, 0),
('spencers', 9, 0),
('erty', 0, 0),
('erty', 1, 0),
('erty', 2, 0),
('erty', 3, 0),
('erty', 4, 0),
('erty', 5, 0),
('erty', 6, 0),
('erty', 7, 0),
('erty', 8, 0),
('erty', 9, 0),
('erty', 10, 0),
('erty', 11, 0),
('erty', 12, 0),
('erty', 13, 0),
('erty', 14, 0);

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE `types` (
  `master` varchar(100) NOT NULL,
  `slave` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`master`, `slave`) VALUES
('Theater', 'sathyam'),
('Theater', 'mayajal'),
('Mall', 'phoenix'),
('Mall', 'spencers'),
('Mall', 'erty');

-- --------------------------------------------------------

--
-- Table structure for table `userdetails`
--

CREATE TABLE `userdetails` (
  `name` varchar(100) NOT NULL,
  `emailid` varchar(100) NOT NULL,
  `mobilenumber` varchar(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdetails`
--

INSERT INTO `userdetails` (`name`, `emailid`, `mobilenumber`, `username`, `password`) VALUES
('', '', '', '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
