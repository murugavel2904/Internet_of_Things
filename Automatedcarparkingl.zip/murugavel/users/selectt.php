<html>
<?php
include('utility.php');
$master=$_POST['master'];
//echo "$master";
?>
<body>
<form action="show.php" method="post">
<select name="slave" value="">
<?php 
$result = mysql_query("SELECT * FROM types where master='$master'");
						while($row = mysql_fetch_array($result))
							{
								$slave=$row['slave'];
								?>
								
								<option><?php echo "$slave"; ?></option>
								<?php
							}


?>
</select>
<input type="submit" value="submit"></form>
</body>
</html>